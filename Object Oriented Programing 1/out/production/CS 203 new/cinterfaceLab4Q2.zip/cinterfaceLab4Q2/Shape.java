package cinterfaceLab4Q2;

public interface Shape {
    public double area();
}
