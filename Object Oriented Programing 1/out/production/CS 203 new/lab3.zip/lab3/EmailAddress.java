package lab3;

public class EmailAddress {
    int type;
    String emailAddress;

    public EmailAddress() {
        this.type =0;
        this.emailAddress ="mitugashe@gmail.com";
    }

    public EmailAddress(int type, String emailAddress) {
        this.type = type;
        this.emailAddress = emailAddress;
    }

}
