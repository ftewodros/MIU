package lab3;

public class PhoneNumber {
    int type;
    int number;

    public PhoneNumber() {
        this.type = 0;
        this.number = 911;
    }

    public PhoneNumber(int type, int number) {
        this.type = type;
        this.number = number;
    }
}
