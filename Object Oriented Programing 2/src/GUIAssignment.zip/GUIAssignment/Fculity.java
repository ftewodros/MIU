package GUIAssignment;

public class Fculity extends Member{

	public Fculity(String name, int id ) {
		super(name, id, 10, 4);
		}

}
