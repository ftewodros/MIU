package GUIAssignment;

public class Book extends Publication {

	public Book(String name, double price) {
		super(name, price, 0.25, price);
			}

	
	

}
