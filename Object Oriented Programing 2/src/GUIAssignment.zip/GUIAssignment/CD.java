package GUIAssignment;

public class CD extends Publication {

	public CD(String name, double price) {
		super(name, price, 0.5, price);
		
			}
	
	

}
