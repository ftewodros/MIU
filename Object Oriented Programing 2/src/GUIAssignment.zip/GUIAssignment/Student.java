package GUIAssignment;

public class Student extends Member{

	public Student(String name, int id) {
		super(name, id, 5, 2);
	}
	
	

}
